. app.env
./build.sh
docker compose -f docker-compose.yml up
