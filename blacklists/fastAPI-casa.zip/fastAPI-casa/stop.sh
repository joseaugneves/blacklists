. app.env
docker stop ${APPNAME}
docker compose -f docker-compose.yml down